package org.example.remindersovernetwork;

public class Server {
    /*
    Connect to a Database
    Receive Data from Clients and save it to the Database
     */
}
