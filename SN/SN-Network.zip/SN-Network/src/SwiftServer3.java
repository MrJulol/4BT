import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SwiftServer3 {
    private static final int[][] winConditions = {
            {0, 1, 2}, {3, 4, 5}, {6, 7, 8},
            {0, 3, 6}, {1, 4, 7}, {2, 5, 8},
            {0, 4, 8}, {2, 4, 6}
    };
    private static final int PORT = 12345;
    private static Socket[] clients = new Socket[2];
    private static PrintWriter[] outStreams = new PrintWriter[2];
    private static BufferedReader[] inStreams = new BufferedReader[2];
    private static char[] board = {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '};
    private static int currentPlayer = 0;
    private static final Lock lock = new ReentrantLock();

    public static void main(String[] args) {
        System.out.println("Server started");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            for (; ; ) {
                Socket client = serverSocket.accept();
                System.out.println("Player connected");
                int playerIndex = (clients[0] == null) ? 0 : 1;
                clients[playerIndex] = client;
                outStreams[playerIndex] = new PrintWriter(client.getOutputStream(), true);
                inStreams[playerIndex] = new BufferedReader(new InputStreamReader(client.getInputStream()));

                new Thread(new ClientHandler(playerIndex)).start();

                if (clients[0] != null && clients[1] != null) {
                    sendInitialMessages();
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void sendMessage(int playerIndex, String message) {
        if (outStreams[playerIndex] != null) {
            outStreams[playerIndex].println(message);
        }
    }

    private static void sendInitialMessages() {
        outStreams[0].println("Yes");
        outStreams[1].println("No");
    }

    private static void sendBoard() {
        for (int i = 0; i < board.length; i++) {
            char symbol = board[i];
            if (symbol != ' ') {
                for (PrintWriter out : outStreams) {
                    if (out != null) {
                        out.println((symbol == 'X' ? "X" : "O") + " " + i);
                    }
                }
            }
        }
    }

    private static boolean makeMove(int playerIndex, int move) {
        if (move < 0 || move >= board.length || board[move] != ' ') {
            sendMessage(playerIndex, "Invalid_move");
            return false;
        }
        sendInitialMessagesInverted();
        board[move] = (playerIndex == 0) ? 'X' : 'O';
        sendBoard();
        return true;
    }

    private static void sendInitialMessagesInverted() {
        outStreams[0].println("No");
        outStreams[1].println("Yes");
    }

    private static boolean checkWin() {
        for (int[] condition : winConditions) {
            if (board[condition[0]] != ' ' && board[condition[0]] == board[condition[1]] && board[condition[1]] == board[condition[2]]) {
                return true;
            }
        }
        return false;
    }

    private static void resetGame() {
        for (int i = 0; i < board.length; i++) {
            board[i] = ' ';
        }
        currentPlayer = 0;
    }

    private static boolean isBoardFull() {
        for (char c : board) {
            if (c == ' ') {
                return false;
            }
        }
        return true;
    }


    private static class ClientHandler implements Runnable {
        private final int playerIndex;

        public ClientHandler(int playerIndex) {
            this.playerIndex = playerIndex;
        }

        @Override
        public void run() {
            try {

                for (; ; ) {
                    String input = inStreams[playerIndex].readLine();
                    if (input == null) {
                        continue;
                    }
                    System.out.println("Player " + playerIndex + ": " + input);
                    lock.lock();
                    try {

                        if (playerIndex != currentPlayer) {
                            sendMessage(playerIndex, "No");
                        } else {
                            int move = Integer.parseInt(input);
                            if (makeMove(playerIndex, move)) {
                                if (checkWin()) {
                                    sendMessage(playerIndex, "WIN");
                                    sendMessage(1 - playerIndex, "Loss");
                                    resetGame();
                                } else if (isBoardFull()) {
                                    sendMessage(playerIndex, "Full");
                                    sendMessage(1 - playerIndex, "Full");
                                    resetGame();
                                } else {
                                    currentPlayer = 1 - currentPlayer;
                                    sendMessage(currentPlayer, (board[move] == 'X' ? "O" : "X") + " " + move);
                                }
                            }
                        }
                    } finally {
                        lock.unlock();
                    }
                }
            } catch (IOException e) {
                System.err.println("Verbindung zu Spieler " + playerIndex + " verloren.");
            }
        }
    }
}





