import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class TicTacToeServer {
    private static final int PORT = 12345;
    private static ExecutorService pool = Executors.newFixedThreadPool(4);
    private static TicTacToeGame game = new TicTacToeGame();

    public static void main(String[] args) {
        System.out.println("TicTacToe Server is running...");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected");
                ClientHandler2 clientHandler = new ClientHandler2(clientSocket, game);
                pool.execute(clientHandler);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
class ClientHandler2 implements Runnable {
    private Socket clientSocket;
    private TicTacToeGame game;
    private BufferedReader in;
    private PrintWriter out;

    public ClientHandler2(Socket socket, TicTacToeGame game) {
        this.clientSocket = socket;
        this.game = game;
    }

    @Override
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            out = new PrintWriter(clientSocket.getOutputStream(), true);

            String input;
            while ((input = in.readLine()) != null) {
                System.out.println("Received: " + input);
                handleClientInput(input);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void handleClientInput(String input) {
        String[] tokens = input.split(" ");
        String command = tokens[0];

        switch (command) {
            case "MOVE":
                int row = Integer.parseInt(tokens[1]);
                int col = Integer.parseInt(tokens[2]);
                char player = tokens[3].charAt(0);
                synchronized (game) {
                    if (game.makeMove(row, col, player)) {
                        if (game.checkForWin()) {
                            out.println("WIN " + player);
                        } else if (game.isBoardFull()) {
                            out.println("DRAW");
                        } else {
                            out.println("OK");
                        }
                    } else {
                        out.println("INVALID");
                    }
                }
                break;
            case "RESET":
                synchronized (game) {
                    game.initializeBoard();
                }
                out.println("RESET OK");
                break;
            default:
                out.println("UNKNOWN COMMAND");
                break;
        }
    }
}

