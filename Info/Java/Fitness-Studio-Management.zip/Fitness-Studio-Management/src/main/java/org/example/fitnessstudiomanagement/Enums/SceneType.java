package org.example.fitnessstudiomanagement.Enums;

public enum SceneType {
    LOGIN, CLIENT, ADMIN, MEMBERSHIP, REGISTER
}
