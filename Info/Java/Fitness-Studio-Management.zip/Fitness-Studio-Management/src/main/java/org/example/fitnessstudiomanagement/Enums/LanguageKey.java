package org.example.fitnessstudiomanagement.Enums;

public enum LanguageKey {
    GERMAN, ITALIAN, ENGLISH
}
