package org.example.fitnessstudiomanagement.Enums;

public enum TranslationKey {
    USERNAME,
    PASSWORD,
    LOGIN,
    SETTINGS,
    REGISTER,
    MEMBERSHIP,
    YOUR_CLIENTS,
    LOGOUT,
    WELCOME,
    LOGIN_NR,
    EXP_DATE,
    DELETE,
    MONTHLY,
    YEARLY,
    QUARTERLY,
    REG_NAME,
    REG_PHONE,
    REG_ADDRESS,
    REG_DATE,
    CANCEL,
    OK,
    CHECKIN,
    BACK
}
