package org.example.fitnessstudiomanagement.Enums;

public enum MembershipType {
    YEARLY, QUARTERLY, MONTHLY
}
